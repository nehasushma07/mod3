package com.cg.ui;
import java.util.Random;
import java.util.Scanner;

import com.cg.bean.ItemSchema;
import com.cg.helper.DataValidator;
import com.cg.helper.CollectionHelper;

public class ItemUi
{
	static Scanner sc=new Scanner(System.in);
	static CollectionHelper collectionhelper=null;
	public static void main(String[] args) 
	{
		
		int choice = 0;
		collectionhelper =new CollectionHelper();

		while(true)
		{
			System.out.println("Please enter your choice :");
			System.out.println("1. Add Item");
			System.out.println("2. Find Total count");
			System.out.println("3. Display records");
			System.out.println("4. Find duplicate records");
			System.out.println("5. remove record");
			System.out.println("6. Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			
			//Calling enterBookDetails method for getting & displaying book details 
			case 1:
				System.out.println("Add Item");
				addItem();
				break;
			case 2:
				System.out.println("Find total count");
				collectionhelper.Totalcount();
				break;
			case 3:
				System.out.println("Display Record");
				collectionhelper.DisplayRecord();
				break;
			case 4:
				System.out.println("Duplicate Record");
				int get_itemId=sc.nextInt();
				collectionhelper.DuplicateRecord(get_itemId);
				break;
			case 5:
				System.out.println("Remove Record");
				collectionhelper.RemoveRecord();
			case 6:
				System.exit(0);
			}
		}
	}
	
	//method for getting & displaying book details
	public static void addItem() 
	{
		
		try
		{
			System.out.println("How many items?");
		int icount=sc.nextInt();
		while(icount!=0)
		{
		System.out.println("Enter item id:");
		String itemId=sc.next();
					//sending input to validateItemId method for validating item id
			
			if(DataValidator.validateItemId(itemId))
			{
				System.out.println("Enter item name:");
				 String itemName=sc.next();
				//sending input to validateItemName method for validating item name
				if(DataValidator.validateItemName(itemName))
				{
					System.out.println("Enter price:");
					String itemPrice=sc.next();
										
					//sending input to validatePrice method for validating item price
				   
					if(DataValidator.validateItemPrice(itemPrice))
					{
												
						//Generate  Random Reference Id
						Random ran=new Random();
						int transactionId=ran.nextInt();
						System.out.println("transaction id:"+transactionId);
						
						//sending valid input data to the constructor of ItemSchema class
						 ItemSchema item=new ItemSchema(Integer.parseInt(itemId),itemName,Double.parseDouble(itemPrice),transactionId);
						collectionhelper.addItem(item);
						icount--;
						
					}
					}	
				}
			
	}
		}
	catch(Exception e)
	{
				
			System.out.println(e.getMessage());
	}
			

	}
}



	


