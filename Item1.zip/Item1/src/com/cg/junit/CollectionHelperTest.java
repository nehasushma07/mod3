package com.cg.junit;
import junit.framework.Assert;

import org.junit.Test;
import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.cg.bean.ItemSchema;
import com.cg.Exception.ItemException;
import com.cg.helper.CollectionHelper;


@SuppressWarnings("deprecation")
public class CollectionHelperTest {
	static CollectionHelper collectionhelper;
	static ItemSchema item = null;
	 
	    @BeforeClass
	public static void beforeClass()
	{
		collectionhelper=new CollectionHelper();
		item = new ItemSchema(4,"Bluetooth",450.25,4564);
	}

	    @AfterClass
	    public static void afterClass()
	    {
	    	collectionhelper = null;
	    	item = null;
	    }
	    @Test
	    public void testaddItem() throws ItemException
	    {
	    	collectionhelper.addItem(item);
	    	Assert.assertNotNull(collectionhelper.toString());
	    }
}
