package com.cg.bean;


public class ItemSchema {
	
	//Purpose: To provide getters and setters for book details
        public int itemId;
		public String itemName;
		public double itemPrice;
		public int transactionId;
		
		//default constructor
		public ItemSchema() {

		}
		
		//initializing instance variables
		public ItemSchema(int itemId, String itemName,double itemPrice,int transactionId ) {
			this.itemId = itemId;
			this.itemName = itemName;
			this.itemPrice = itemPrice;
			this.transactionId = transactionId;
		}

		public int getItemId() {
			return itemId;
		}

		public void setItemId(int itemId) {
			this.itemId = itemId;
		}

		public String getItemName() {
			return itemName;
		}

		public void setItemName(String itemName) {
			this.itemName = itemName;
		}

		public double getItemPrice() {
			return itemPrice;
		}

		public void setItemPrice(double itemPrice) {
			this.itemPrice = itemPrice;
		}

		public int getTransactionId() {
			return transactionId;
		}

		public void setTransactionId(int transactionId) {
			this.transactionId = transactionId;
		}
		

//displaying item details 

public String toString() {
	return "Item[Item Id=" + itemId + ", Item Name="
			+ itemName + ", Item Price=" + itemPrice +", transaction Id=" + transactionId
			+ "]";
}
}
