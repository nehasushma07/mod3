

package com.cg.Exception;

public class ItemException extends Exception 
{
	private static final long serialVersionUID = 1L;
	public ItemException()
	{
		super();
	}
	public ItemException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public ItemException(String message, Throwable cause) 
	{
		super(message, cause);
	}
	public ItemException(String message) 
	{
		super(message);			
	}
	public ItemException(Throwable cause) 
	{
		super(cause);			
	}
}

