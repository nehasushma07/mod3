package com.cg.helper;
import java.util.ArrayList;
import java.util.Iterator;
import com.cg.bean.ItemSchema;


public class CollectionHelper 
{
	private static ArrayList<ItemSchema>Itemlist=new ArrayList<ItemSchema>();
	static
	{
		ItemSchema i1=new ItemSchema(1,"Camera",60000.5,320);
		ItemSchema i2=new ItemSchema(2,"Smartphone",40000.5,321);
		ItemSchema i3=new ItemSchema(3,"WashingMachine",30000.5,322);
		Itemlist.add(i1);
		Itemlist.add(i2);
		Itemlist.add(i3);
	}
	public void addItem(ItemSchema item)
	{
		Itemlist.add(item);
	}
	
  public void Totalcount()
  {
	  Iterator<ItemSchema> ItemIt=Itemlist.iterator();
	  int totalCount=0;
	  while(ItemIt.hasNext())
	  {
		  totalCount++;
		  
	  }
	  System.out.println("TotalCount of Items:"+totalCount);
  }
  public void DisplayRecord()
  {
	  for(Object item: Itemlist)
			System.out.println(item);
  }
  public void DuplicateRecord(int itemId)
  {
	  for(Object item: Itemlist)
		{
			ItemSchema obj=(ItemSchema)item;
			if(obj.itemId == itemId)
			{
				System.out.println(item);
			}
		}
  }
  public void RemoveRecord()
  {
	  
	  
  }
  
}


	