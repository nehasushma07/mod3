package com.cg.helper;


import java.util.regex.Pattern;

public class DataValidator{
	public static boolean validateItemId(String itemId) throws Exception
	{
		String idpattern = "(\\d+)";
				if(Pattern.matches(idpattern, itemId))
				{
					return true;
				}
				else
				{
					throw new Exception("Item id should contain digits");
				}
	}
	public static boolean validateItemName(String itemName) throws Exception
	{
		String namepatt="[A-Za-z]{6,20}";
				if(Pattern.matches(namepatt, itemName))
				{
					return true;
				}
				else
				{
					throw new Exception("Item should contain only alphabets");
				}
	}
	public static boolean validateItemPrice(String itemPrice) throws Exception
	{
		String pricepatt="[0-9]{1,6}.[0-9]{1,2}";
				if(Pattern.matches(pricepatt,itemPrice))
				{
					return true;
				}
				else
				{
					throw new Exception("price should always contain digits");
				}
	}

}
